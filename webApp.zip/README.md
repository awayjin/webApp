# webApp

## 触屏版

## 安装
    首先安装依赖的JS, 安装在app/目录下: bower install